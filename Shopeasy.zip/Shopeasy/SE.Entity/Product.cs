﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SE.Entity
{
    /// <summary>
    /// Employee ID : 121639
    /// Employee Name : Aishwarya Dudgol
    /// Description : This Class ha Structure of Product Class
    /// Date Of Creation : 4th April,2017
    /// </summary>
       
    public class Product
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }
        public int SupplierID { get; set; }
        public int CategoryID { get; set; }
        public int Units { get; set; }
        public int UnitPrice { get; set; }
        public int MRP { get; set; }
        public decimal Discount { get; set; }
        public byte[] Picture { get; set; }
        public int Ranking { get; set; }
        public string ProductDesc { get; set; }
        public DateTime DOM { get; set; }
        public string CategorygDesc { get; set; }
    }
}
