﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SE.Entity
{
     /// <summary>
    /// Employee ID : 121639
    /// Employee Name : Aishwarya Dudgol
    /// Description : This Class has Structure Of Supplier Class
    /// Date Of Creation : 4th April,2017
    /// </summary>
   
    public class Supplier
    {
        public int SupplierID { get; set; }
        public string CompanyName { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string PostalCode { get; set; }
        public string MobileNo { get; set; }
        public string EmailId { get; set; }
        public string Website { get; set; }
        public int Ranking { get; set; }
        public string Note { get; set; }
        public string Password { get; set; }
    }
}
