﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SE.Entity;
using SE.Exception;
using SE.DAL;
using System.Data;
using System.Data.SqlClient;
namespace SE.PL.Women
{
    public partial class Clothing : System.Web.UI.Page
    {
        ProductOperations po = new ProductOperations();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnOrder_Click(object sender, EventArgs e)
        {

        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable tb = new DataTable();
                tb = po.getProductByName(RadioButtonList1.SelectedItem.Text);
                DataSet ds = new DataSet();
                ds.Tables.Add(tb);
                txtPPrice.Visible = true;
                txtPName.Visible = true;
                txtpDesc.Visible = true;
                imageProduct.Visible = true;
                txtPName.Text = ds.Tables[0].Rows[0][1].ToString();
                txtpDesc.Text = ds.Tables[0].Rows[0][10].ToString();
                txtPPrice.Text = ds.Tables[0].Rows[0][6].ToString();
                Byte[] data = new Byte[0];
                data = (Byte[])(ds.Tables[0].Rows[0][8]);
                string base64String = Convert.ToBase64String(data, 0, data.Length);
                imageProduct.ImageUrl = "data:image/png;base64," + base64String;
                btnOrder.Visible = true;
            }
            catch (SqlException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (CustomException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
            catch (SystemException ex)
            {
                Response.Write("<script>alert('" + ex.Message + "');</script>");
            }
        }
    }
}