﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace SE.PL
{
    public partial class Main : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public string searchProduct
        {
            get { return txtSearch.Text; }
            set { txtSearch.Text = value; }
        }
        public bool Login
        {
            get { return lbtnLogin.Visible; }
            set {lbtnLogin.Visible = value; }
        }
        public bool Logout
        {
            get { return lbtnLogout.Visible; }
            set { lbtnLogout.Visible = value; }
        }
    }
}