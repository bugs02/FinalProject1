﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SE.Entity;
using SE.Exception;
using SE.DAL;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
namespace SE.BL
{
    public class CustomValidation
    {
        Operations op = new Operations();
        DataTable table;

        public bool validateSuppliers(Supplier sp)
        {
            bool supplidersValidated = true;
            StringBuilder sb = new StringBuilder();
            try
            {
                if(sp.CompanyName==String.Empty)
                {
                    sb.Append("Please Enter Company Name\n");
                    supplidersValidated = false;
                }
                if (sp.Address1 == String.Empty)
                {
                    sb.Append("Please Add Address\n");
                    supplidersValidated = false;
                }
                if (sp.Address2 == String.Empty)
                {
                    sb.Append("Please Add Address\n");
                    supplidersValidated = false;
                }
                if (sp.City == String.Empty)
                {
                    sb.Append("Enter City Name\n");
                    supplidersValidated = false;
                }
                if (sp.PostalCode.ToString() == String.Empty)
                {
                    sb.Append("Enter valid Pincode\n");
                    supplidersValidated = false;
                }
                if (sp.MobileNo == String.Empty)
                {
                    sb.Append("Enter Mobile Number\n");
                    supplidersValidated = false;
                }
                else if (!Regex.IsMatch(sp.MobileNo, @"^[789]\d{9}$"))
                {
                    sb.Append("Enter Proper Mobile number\n");
                    supplidersValidated = false;
                }
                if(sp.EmailId==String.Empty)
                {
                    sb.Append("Enter Email ID\n");
                    supplidersValidated = false;
                }
                else if (!Regex.IsMatch(sp.EmailId, @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$"))
                {
                    sb.Append("Enter Valid Email ID\n");
                    supplidersValidated = false;
                }
                if(sp.Website==String.Empty)
                {
                    sb.Append("Enter Web Site\n");
                    supplidersValidated = false;
                }
                else if (!Regex.IsMatch(sp.Website, @"^http(s)?://([\w-]+.)+[\w-]+(/[\w- ./?%&=])?$"))
                {
                    sb.Append("Enter Valid URL\n");
                    supplidersValidated = false;
                }
                if (sp.Ranking.ToString() == String.Empty)
                {
                    sb.Append("Enter Ranking\n");
                    supplidersValidated = false;
                }
                if(sp.Note==String.Empty)
                {
                    sb.Append("Enter Note\n");
                    supplidersValidated = false;
                }
                if(sp.Password==String.Empty)
                {
                    sb.Append("Enter Password\n");
                    supplidersValidated = false;
                }
                if(supplidersValidated==false)
                {
                    throw new CustomerException(sb.ToString());
                }
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch(SystemException ex)
            {
                throw;
            }
            return supplidersValidated;
        }
        public bool AddSupplier(Supplier sp)
        {
            bool supplierAdded = false;
            try
            {
                if(validateSuppliers(sp))
                {
                    supplierAdded = op.AddSupplier(sp);
                }
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return supplierAdded;
        }
        public int supplierID()
        {
            int supplierID = 0;
            try
            {
                supplierID = op.supplierID();
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return supplierID;
        }
        public bool authSupplier(int SID,string pass)
        {
            bool supplierAuth = false;
            try
            {
                supplierAuth = op.authSupplier(SID, pass);
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return supplierAuth;
        }
        public DataTable getCategory()
        {
            table = new DataTable();
            try
            {
                table = op.getCategory();
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return table;
        }
        public bool validateProducts(Product prd)
        {
            bool productValidated = true;
            try
            {
                StringBuilder sb = new StringBuilder();
                if(prd.ProductName==String.Empty)
                {
                    sb.Append("Enter Product Name\n");
                    productValidated = false;
                }
                if (prd.SupplierID.ToString() == String.Empty)
                {
                    sb.Append("Enter Supplier ID\n");
                    productValidated = false;
                }
                if (prd.CategoryID.ToString() == String.Empty)
                {
                    sb.Append("Enter Category ID\n");
                    productValidated = false;
                }
                if (prd.Units.ToString() == String.Empty)
                {
                    sb.Append("Enter Units");
                    productValidated = false;
                }
                if (prd.UnitPrice.ToString() == String.Empty)
                {
                    sb.Append("Enter Unit Price\n");
                    productValidated = false;
                }
                if (prd.MRP.ToString() == String.Empty)
                {
                    sb.Append("Enter MRP\n");
                    productValidated = false;
                }
                if (prd.Discount.ToString() == String.Empty)
                {
                    sb.Append("Enter Discount\n");
                    productValidated = false;
                }
                if (prd.Ranking.ToString() == String.Empty)
                {
                    sb.Append("Enter Rank\n");
                    productValidated = false;
                }
                if (prd.ProductDesc == String.Empty)
                {
                    sb.Append("Enter Product Product Description\n");
                    productValidated = false;
                }
                if (prd.DOM.ToString() == String.Empty)
                {
                    sb.Append("Enter Date\n");
                    productValidated = false;
                }
                if (prd.CategorygDesc==String.Empty)
                {
                    sb.Append("Enter Category Description\n");
                    productValidated = false;
                }
                if(productValidated==false)
                {
                    throw new CustomerException(sb.ToString());
                }
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return productValidated;
        }
        public bool addProduct(Product prd)
        {
            bool productAdded = false;
            try
            {
                productAdded = op.addProduct(prd);
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return productAdded;
        }
        public DataTable viewProduct()
        {
            table = new DataTable();
            try
            {
                table = op.viewProduct();
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return table;
        }
        public DataTable viewCustomer()
        {
            table = new DataTable();
            try
            {
                table = op.viewCustomer();
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return table;
        }
        public DataTable viewOrder()
        {
            table = new DataTable();
            try
            {
                table = op.viewOrder();
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return table;
        }
        public DataTable viewSupplier()
        {
            table = new DataTable();
            try
            {
                table = op.viewSupplier();
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return table;
        }
        public bool validateCustomers(Customer cust)
        {
            bool customerValidated = true;
            try
            {
                StringBuilder sb = new StringBuilder();
                if (cust.CFName == String.Empty)
                {
                    sb.Append("Enter Your First Name\n");
                    customerValidated = false;
                }
                if (cust.CLName == String.Empty)
                {
                    sb.Append("Enter Your Last Name\n");
                    customerValidated = false;
                }
                if (cust.Email == String.Empty)
                {
                    sb.Append("Enter Your Email ID\n");
                    customerValidated = false;
                }
                else if (!Regex.IsMatch(cust.Email, @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$"))
                {
                    sb.Append("Enter Valid Email ID\n");
                    customerValidated = false;
                }
                if (cust.Mobile == String.Empty)
                {
                    sb.Append("Enter Your Mobile Number\n");
                    customerValidated = false;
                }
                else if (!Regex.IsMatch(cust.Mobile, @"^[789]\d{9}$"))
                {
                    sb.Append("Enter Proper Mobile number\n");
                    customerValidated = false;
                }
                if (cust.UserID == String.Empty)
                {
                    sb.Append("Enter Your User ID\n");
                    customerValidated = false;
                }
                if (cust.Pass == String.Empty)
                {
                    sb.Append("Enter Your Password\n");
                    customerValidated = false;
                }
                if (customerValidated == false)
                {
                    throw new CustomerException(sb.ToString());
                }
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return customerValidated;
        }
        public bool addCustomer(Customer cust)
        {
            bool customerAdded = false;
            try
            {   
                if(validateCustomers(cust))
                {
                    customerAdded = op.addCustomer(cust);
                }
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return customerAdded;
        }
        public DataTable searchCustomer(string CID,string pass)
        {
            table = new DataTable();
            try
            {
                table = op.searchCustomer(CID, pass);
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return table;
        }
        public bool validateOrders(Order ord)
        {
            bool orderValidated = true;
            try
            {
                StringBuilder sb = new StringBuilder();
                if (ord.ODate.ToString() == String.Empty)
                {
                    sb.Append("Enter Order Date\n");
                    orderValidated = false;
                }
                if (ord.CustomerID.ToString() == String.Empty)
                {
                    sb.Append("Enter CustomerID\n");
                    orderValidated = false;
                }
                if (ord.ProductID.ToString() == String.Empty)
                {
                    sb.Append("Enter Product ID\n");
                    orderValidated = false;
                }
                if (ord.Price.ToString() == String.Empty)
                {
                    sb.Append("Enter Price\n");
                    orderValidated = false;
                }
                if (ord.Quantity.ToString() == String.Empty)
                {
                    sb.Append("Enter Quantity\n");
                    orderValidated = false;
                }
                else if (ord.Quantity < 0)
                {
                    sb.Append("Enter Quantity More than 0\n");
                }
                if (ord.Total.ToString() == String.Empty)
                {
                    sb.Append("Enter Total\n");
                    orderValidated = false;
                }
                if (ord.BARoomNo.ToString() == String.Empty)
                {
                    sb.Append("Enter Billing Address Room No.\n");
                    orderValidated = false;
                }
                if (ord.BACity.ToString() == String.Empty)
                {
                    sb.Append("Enter Billing Address City\n");
                    orderValidated = false;
                }
                if (ord.BAState.ToString() == String.Empty)
                {
                    sb.Append("Enter Billing Address State\n");
                    orderValidated = false;
                }
                if (ord.BAPincode.ToString() == String.Empty)
                {
                    sb.Append("Enter Billing Address Pincode\n");
                    orderValidated = false;
                }
                if (ord.SARoomNo.ToString() == String.Empty)
                {
                    sb.Append("Enter Shiiping Address Room No.\n");
                    orderValidated = false;
                }
                if (ord.SACity.ToString() == String.Empty)
                {
                    sb.Append("Enter Shiiping Address City\n");
                    orderValidated = false;
                }
                if (ord.SAState.ToString() == String.Empty)
                {
                    sb.Append("Enter Shiiping Address Sate\n");
                    orderValidated = false;
                }
                if (ord.SAPincode.ToString() == String.Empty)
                {
                    sb.Append("Enter Shiiping Address Pincode\n");
                    orderValidated = false;
                }
                if (orderValidated == false)
                {
                    throw new CustomerException(sb.ToString());
                }
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return orderValidated;
        }
        public bool addOrder(Order ord)
        {
            bool orderAdded = false;
            try
            {
                if (validateOrders(ord))
                {
                    orderAdded = op.addOrder(ord);
                }
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return orderAdded;
        }
        public DataTable searchCategory(string type)
        {
            table = new DataTable();
            try
            {
                table = op.searchCategory(type);
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return table;
        }
        public DataTable searchProduct(string type,string type1)
        {
            table = new DataTable();
            try
            {
                table = op.searchProduct(type, type1);
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return table;
        }
        public DataTable getProductByName(string type)
        {
            table = new DataTable();
            try
            {
                table = op.getProductByName(type);
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return table;
        }

        public int ProdQuantCheck(string ProdName)
        {   
            int quantity;

            try
            {
                quantity = op.ProdQuantCheck(ProdName);
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return quantity;
        }
        public bool updateProduct(int quantity, string name)
        {
            bool productUpdated = false;
            try
            {
                productUpdated = op.updateProduct(quantity, name);
            }
            catch (CustomerException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }
            return productUpdated;
        }
    }
}
