﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using SE.Entity;
using SE.Exception;

namespace SE.DAL
{
    /// <summary>
    /// Employee ID :
    /// Employee Name :
    /// Description :
    /// Date Of Creation : 
    /// </summary>
    
    public class ProductOperations
    {
        SqlCommand cmd = DataConfiguration.CreateCommand();
        DataTable table;
        SqlDataReader dr;

        //Method For Adding Products
        public bool addProduct(Product prd)
        {
            bool productAdded = false;
            try
            {
                cmd.CommandText = "EC.addProduct";
                cmd.Parameters.AddWithValue("@PName", prd.ProductName);
                cmd.Parameters.AddWithValue("@SID", prd.SupplierID);
                cmd.Parameters.AddWithValue("@CID", prd.CategoryID);
                cmd.Parameters.AddWithValue("@Units", prd.Units);
                cmd.Parameters.AddWithValue("@UPrice", prd.UnitPrice);
                cmd.Parameters.AddWithValue("@MRP", prd.MRP);
                cmd.Parameters.AddWithValue("@Discount", prd.Discount);
                cmd.Parameters.AddWithValue("@Picture", prd.Picture);
                cmd.Parameters.AddWithValue("@Rank", prd.Ranking);
                cmd.Parameters.AddWithValue("@PDesc", prd.ProductDesc);
                cmd.Parameters.AddWithValue("@DOM", prd.DOM);
                cmd.Parameters.AddWithValue("@CDesc", prd.CategorygDesc);

                cmd.Connection.Open();

                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    productAdded = true;
                }
                cmd.Connection.Close();
            }
            catch (CustomException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return productAdded;
        }

        //public bool SearchProduct(String ProdName)
        //{
        //    bool ProductFound = false;
        //    try
        //    {
        //        cmd.CommandText = "EC.searchProduct";
        //        cmd.Parameters.AddWithValue("@Sid", ProdName);
        //        cmd.Connection.Open();

        //        int result = cmd.ExecuteNonQuery();
        //        if (result > 0)
        //        {
        //            ProductFound = true;
        //        }

        //        cmd.Connection.Close();

        //    }
        //    catch (CustomException ex)
        //    {
        //        throw;
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw;
        //    }

        //    return ProductFound;
        //}

        //Method For Updating Product Details
        public bool updateProduct(Product prd)
        {
            bool productUpdated = false;
            try
            {
                cmd.CommandText = "EC.updateProduct";
                cmd.Parameters.AddWithValue("@PName", prd.ProductName);
                cmd.Parameters.AddWithValue("@SID", prd.SupplierID);
                cmd.Parameters.AddWithValue("@CID", prd.CategoryID);
                cmd.Parameters.AddWithValue("@Units", prd.Units);
                cmd.Parameters.AddWithValue("@UPrice", prd.UnitPrice);
                cmd.Parameters.AddWithValue("@MRP", prd.MRP);
                cmd.Parameters.AddWithValue("@Discount", prd.Discount);
                cmd.Parameters.AddWithValue("@Picture", prd.Picture);
                cmd.Parameters.AddWithValue("@Rank", prd.Ranking);
                cmd.Parameters.AddWithValue("@PDesc", prd.ProductDesc);
                cmd.Parameters.AddWithValue("@DOM", prd.DOM);
                cmd.Parameters.AddWithValue("@CDesc", prd.CategorygDesc);

                cmd.Connection.Open();

                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    productUpdated = true;
                }

                cmd.Connection.Close();
            }
            catch (CustomException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return productUpdated;
        }

        //Method For Deleting a Product Record
        public bool deleteProduct(string productName)
        {
            bool productDeleted = false;
            try
            {
                cmd.CommandText = "EC.deleteProduct";
                cmd.Parameters.AddWithValue("@PName", productName);
                cmd.Connection.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    productDeleted = true;
                }
                cmd.Connection.Close();
            }
            catch (CustomException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return productDeleted;
        }

        //Method For Displaying All Product Details
        public DataTable viewProduct()
        {
            table = new DataTable();

            try
            {
                cmd.CommandText = "EC.viewProducts";
                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
                cmd.Connection.Close();
            }
            catch (CustomException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return table;
        }

        //Method For Searching a Product Depending On Category And Sub-Category
        public DataTable searchProduct(string type, string type1)
        {
            table = new DataTable();
            try
            {
                cmd.CommandText = "[EC].[searchProduct]";
                cmd.Parameters.AddWithValue("@Type", type);
                cmd.Parameters.AddWithValue("@Type1", type1);
                cmd.Connection.Open();
                dr = cmd.ExecuteReader();
                table.Load(dr);
                cmd.Connection.Close();

            }
            catch (CustomException ex)
            {
                throw;
            }
            catch (SqlException ex)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw;
            }

            return table;
        }

        //Method For Fetching a particular Product Details Depending on Product Selected  
        //public DataTable getProductByName(string type)
        //{
        //    table = new DataTable();
        //    try
        //    {
        //        cmd.CommandText = "[EC].[getProductByName]";
        //        cmd.Parameters.AddWithValue("@Type", type);
        //        cmd.Connection.Open();
        //        dr = cmd.ExecuteReader();
        //        table.Load(dr);
        //        cmd.Connection.Close();

        //    }
        //    catch (CustomException ex)
        //    {
        //        throw;
        //    }
        //    catch (SqlException ex)
        //    {
        //        throw;
        //    }
        //    catch (SystemException ex)
        //    {
        //        throw;
        //    }

        //    return table;
    }
}

