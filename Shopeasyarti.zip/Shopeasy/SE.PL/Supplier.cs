﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SE.Entity;
using SE.Exception;
using SE.BL;
using System.Data.SqlClient;

namespace SE.PL
{
    public partial class Supplier : Form
    {
        public Supplier()
        {
            InitializeComponent();
        }
        public bool isNumber;
        public int result;
        CustomValidation cv = new CustomValidation();
        public static byte[] ImageToByteArray(Image img, PictureBox picBox)
        {
            System.IO.MemoryStream ms = new System.IO.MemoryStream();
            if (picBox.Image != null)
            {
                img.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
            }
            return ms.ToArray();
        }
        private void linklblLogOut_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            SupplierLogin sl = new SupplierLogin();
            sl.Show();
            this.Hide();
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            openFileDialog1.Title = "Open Image";
            openFileDialog1.Filter = "jpg files (*.jpg)|*.jpg";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                picBox.Load(openFileDialog1.FileName);
               
            }
        }

        private void Supplier_Activated(object sender, EventArgs e)
        {
            lblSID.Text = SupplierLogin.SID.ToString();
            txtSID.Text = SupplierLogin.SID.ToString();
        }

        private void Supplier_Load(object sender, EventArgs e)
        {
            try
            {
                DataTable table = new DataTable();
                table = cv.getCategory();
                DataSet ds = new DataSet();
                ds.Tables.Add(table);
                for (int i = 0; i < table.Rows.Count; i++)
                {
                    cmbCID.Items.Add(ds.Tables[0].Rows[i][1].ToString() + "-" + ds.Tables[0].Rows[i][2].ToString());
                }
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSaveSupplier_Click(object sender, EventArgs e)
        {
            Product prd = new Product();
            prd.ProductName = txtPName.Text;
            prd.SupplierID = Convert.ToInt32(txtSID.Text);
            prd.CategoryID = cmbCID.SelectedIndex+ 100001;
            isNumber = int.TryParse(txtUnits.Text, out result);
            if (isNumber)
                prd.Units = result;
            else
            {
                MessageBox.Show("Units Must Contain Digits Only", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            isNumber = int.TryParse(txtUnitPrice.Text, out result);
            if (isNumber)
                prd.UnitPrice = result;
            else
            {
                MessageBox.Show("Unit Price Must Contain Digits Only", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            isNumber = int.TryParse(txtMRP.Text, out result);
            if (isNumber)
                prd.MRP = result;
            else
            {
                MessageBox.Show("MRP Must Contain Digits Only", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            decimal result1;
            isNumber = decimal.TryParse(txtDiscount.Text, out result1);
            if (isNumber)
                prd.Discount = result1;
            else
            {
                MessageBox.Show("MRP Must Contain Digits Only", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            prd.Picture= ImageToByteArray(picBox.Image, picBox);
            isNumber = decimal.TryParse(txtRanking.Text, out result1);
            if (isNumber)
                prd.Ranking = result;
            else
            {
                MessageBox.Show("nking must be in 1-5", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            prd.ProductDesc = txtDesc.Text;
            prd.DOM = DateTime.Now;
            if (cmbCID.SelectedIndex <= 3)
                prd.CategorygDesc = "Electronics";
            else if (cmbCID.SelectedIndex <= 7 && cmbCID.SelectedIndex >= 4)
                prd.CategorygDesc = "Home appliances";
            else if (cmbCID.SelectedIndex <= 11 && cmbCID.SelectedIndex >= 8)
                prd.CategorygDesc = "Men";
            else if(cmbCID.SelectedIndex <= 15 && cmbCID.SelectedIndex >= 12)
                prd.CategorygDesc = "Women";           
            try
            {
                bool flag = cv.addProduct(prd);
                if (flag)
                {
                    MessageBox.Show("Product Added Successfully");
                    this.txtPName.Clear();
                    this.cmbCID.SelectedIndex = 0;
                    this.txtUnits.Clear();
                    this.txtUnitPrice.Clear();
                    this.txtMRP.Clear();
                    this.txtDiscount.Clear();
                    this.picBox.Image = null;
                    this.txtRanking.Clear();
                    this.txtDesc.Clear();
                }
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
