﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using SE.Entity;
using SE.Exception;
using SE.BL;
using System.IO;

namespace SE.PL
{
    public partial class HomePage : Form
    {
        int quantity;
        bool isNumber;
        int result;
        private int imageNumber = 1;
        CustomValidation cv = new CustomValidation();
        public void ClearAll()
        {
            this.tabCnt.SelectTab("tpHome");
            //ord.ODate = DateTime.Now;
            
            txtHAQuantity.Clear();
            txtHATotal.Clear();
            txtHADesc.Clear();
            picboxHA.Image = null;
            txtHABARoomNo.Clear();
            txtHABACity.Clear();
            txtHABAPincode.Clear();
            txtHASARoomNo.Clear();
            txtHASACity.Clear();
            txtHASAPincode.Clear();
            cmbElecBAState.SelectedIndex = -1;
            cmbHABAState.SelectedIndex = -1;
            cmbMenBAState.SelectedIndex = -1;
            cmbWomenBAState.SelectedIndex = -1;

            //cmbElecCategory.SelectedIndex = -1;
            //cmbElecProduct.SelectedIndex = -1;
            //cmbHACategory.SelectedIndex = -1;
            //cmbHAProduct.SelectedIndex = -1;
            //cmbMenCategory.SelectedIndex = -1;
            //cmbMenProduct.SelectedIndex = -1;
            //cmbWomenCategory.SelectedIndex = -1;
            //cmbWomenProduct.SelectedIndex = -1;
            

            cmbElecSAState.SelectedIndex = -1;
            cmbHASAState.SelectedIndex = -1;
            cmbMenSAState.SelectedIndex = -1;
            cmbWomenSAState.SelectedIndex = -1;

            
            txtElecQuantity.Clear();
            txtElecTotal.Clear();
            txtElecDesc.Clear();
            picboxElec.Image = null;
            txtElecBARoomNo.Clear();
            txtElecBACity.Clear();
            txtElecBAPincode.Clear();
            txtElecSARoomNo.Clear();
            txtElecSACity.Clear();
            txtElecSAPincode.Clear();
            panelElecCart.Visible = false;

            
            txtMenQuantity.Clear();
            txtMenTotal.Clear();
            txtMenDesc.Clear();
            picboxMen.Image = null;
            txtMenBARoomNo.Clear();
            txtMenBACity.Clear();
            txtMenBAPincode.Clear();
            txtMenSARoomNo.Clear();
            txtMenSACity.Clear();
            txtMenSAPincode.Clear();
            panelHACart.Visible = false;

            
            txtWomenQuantity.Clear();
            txtWomenTotal.Clear();
            txtMenDesc.Clear();
            picboxWomen.Image = null;
            txtWomenBARoomNo.Clear();
            txtWomenBACity.Clear();
            txtWomenBAPincode.Clear();
            txtWomenSARoomNo.Clear();
            txtWomenSACity.Clear();
            txtWomenSAPincode.Clear();
            panelMenCart.Visible = false;
            panelWomenCart.Visible = false; 
        }

        private void loadNextImage()
        {
            if (imageNumber == 4)
            {
                imageNumber = 1;
            }
            picboxHomeAdd.Load(string.Format(@".\Images\logo{0}.jpg", imageNumber));
            imageNumber++;
        }
        public HomePage()
        {
            InitializeComponent();
        }

        private void btnAddToCart_Click(object sender, EventArgs e)
        {

        }

        private void HomePage_Load(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = new DataTable();
                dt = cv.searchCategory("Electronics");
                DataSet ds = new DataSet();
                ds.Tables.Add(dt);
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    cmbElecCategory.Items.Add(ds.Tables[0].Rows[i][0].ToString());
                }
                dt = new DataTable();
                dt = cv.searchCategory("Home Appliances");
                ds.Tables.Add(dt);
                for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                {
                    cmbHACategory.Items.Add(ds.Tables[1].Rows[i][0].ToString());
                }
                dt = new DataTable();
                dt = cv.searchCategory("Men");
                ds.Tables.Add(dt);
                for (int i = 0; i < ds.Tables[2].Rows.Count; i++)
                {
                    cmbMenCategory.Items.Add(ds.Tables[2].Rows[i][0].ToString());
                }
                dt = new DataTable();
                dt = cv.searchCategory("Women");
                ds.Tables.Add(dt);
                for (int i = 0; i < ds.Tables[3].Rows.Count; i++)
                {
                    cmbWomenCategory.Items.Add(ds.Tables[3].Rows[i][0].ToString());
                }

            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void HomePage_Activated(object sender, EventArgs e)
        {
            if (Login.user != null)
            {
                lblUserName.Text = Login.user;
                lblUID.Text = Login.Uid;
                lblUserName.Visible = true;
                linlabLogOut.Visible = true;
                linlabLogin.Visible = false;
            }
            else
            {
                linlabLogin.Visible = true;
            }

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            loadNextImage();
        }

        private void linlabLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Login lg = new Login();
            lg.Show();
        }

        private void linlabLogOut_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            MessageBox.Show("Logged Out");
            this.tabCnt.SelectTab("tpHome");
            Login.user = null;
            lblUserName.Text = "";
            linlabLogOut.Visible = false;
            linlabLogin.Visible = true;
            HomePage hp = new HomePage();
            hp.Show();
            this.Close();
        }

        private void btnElecAddToCart_Click(object sender, EventArgs e)
        {
            try
            {
                if (lblUserName.Text == "")
                {
                    this.Hide();
                    Login lg = new Login();
                    lg.Show();
                }
                else
                {
                    quantity = cv.ProdQuantCheck(cmbElecProduct.SelectedItem.ToString());
                    if (quantity > 0)
                    {
                        panelElecCart.Visible = true;
                    }
                    else
                    {
                        MessageBox.Show("Product Not Available");
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show("Please select product first");
            }
          
        }

        private void btnHAAddToCart_Click(object sender, EventArgs e)
        {
            try
            {
                if (lblUserName.Text == "")
                {
                    this.Hide();
                    Login lg = new Login();
                    lg.Show();
                }
                else
                {
                    quantity = cv.ProdQuantCheck(cmbHAProduct.SelectedItem.ToString());
                    if (quantity > 0)
                    {
                        panelHACart.Visible = true;
                    }
                    else
                    {
                        MessageBox.Show("Product Not Available");
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show("Please select product first");
            }
        }

        private void btnMenAddToCart_Click(object sender, EventArgs e)
        {
            try
            {
                if (lblUserName.Text == "")
                {
                    this.Hide();
                    Login lg = new Login();
                    lg.Show();
                }
                else
                {
                    quantity = cv.ProdQuantCheck(cmbMenProduct.SelectedItem.ToString());
                    if (quantity > 0)
                    {
                        panelMenCart.Visible = true;
                    }
                    else
                    {
                        MessageBox.Show("Product Not Available");
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show("Please select product first");
            }
        }

        private void btnWomenAddToCart_Click(object sender, EventArgs e)
        {
            try
            {
                if (lblUserName.Text == "")
                {
                    this.Hide();
                    Login lg = new Login();
                    lg.Show();
                }
                else
                {
                    quantity = cv.ProdQuantCheck(cmbWomenProduct.SelectedItem.ToString());
                    if (quantity > 0)
                    {
                        panelWomenCart.Visible = true;
                    }
                    else
                    {
                        MessageBox.Show("Product Not Available");
                    }

                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show("Please select product first");
            }
        }

        private void lblUser_Click(object sender, EventArgs e)
        {

        }

        private void cmbElecCategory_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable tb = new DataTable();
                tb = cv.searchProduct(cmbElecCategory.SelectedItem.ToString(), "Electronics");
                DataSet ds = new DataSet();
                ds.Tables.Add(tb);
                cmbElecProduct.Items.Clear();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    cmbElecProduct.Items.Add(ds.Tables[0].Rows[i][1].ToString());
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbHACategory_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable tb = new DataTable();
                tb = cv.searchProduct(cmbHACategory.SelectedItem.ToString(), "Home Appliances");
                DataSet ds = new DataSet();
                ds.Tables.Add(tb);
                cmbHAProduct.Items.Clear();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    cmbHAProduct.Items.Add(ds.Tables[0].Rows[i][1].ToString());
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbMenCategory_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable tb = new DataTable();
                tb = cv.searchProduct(cmbMenCategory.SelectedItem.ToString(), "Men");
                DataSet ds = new DataSet();
                ds.Tables.Add(tb);
                cmbMenProduct.Items.Clear();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    cmbMenProduct.Items.Add(ds.Tables[0].Rows[i][1].ToString());
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbWomenCategory_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable tb = new DataTable();
                tb = cv.searchProduct(cmbWomenCategory.SelectedItem.ToString(), "Women");
                DataSet ds = new DataSet();
                ds.Tables.Add(tb);
                cmbWomenProduct.Items.Clear();
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    cmbWomenProduct.Items.Add(ds.Tables[0].Rows[i][1].ToString());
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbElecProduct_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable tb = new DataTable();
                tb = cv.getProductByName(cmbElecProduct.SelectedItem.ToString());
                DataSet ds = new DataSet();
                ds.Tables.Add(tb);
                txtElecPID.Text = ds.Tables[0].Rows[0][0].ToString();
                txtElecPrice.Text = ds.Tables[0].Rows[0][6].ToString();
                txtElecDesc.Text = ds.Tables[0].Rows[0][10].ToString();
                Byte[] data = new Byte[0];
                data = (Byte[])(ds.Tables[0].Rows[0][8]);
                MemoryStream mem = new MemoryStream(data);
                picboxElec.Image = Image.FromStream(mem);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnElecBuy_Click(object sender, EventArgs e)
        {
                Order ord = new Order();
                ord.ODate = DateTime.Now;
                ord.CustomerID = Convert.ToInt32(lblUID.Text);
                ord.ProductID = Convert.ToInt32(txtElecPID.Text);
                ord.Price = Convert.ToInt32(txtElecPrice.Text);
                isNumber = int.TryParse(txtElecQuantity.Text, out result);
                if (isNumber)
                    ord.Quantity = result;
                else
                {
                    MessageBox.Show("Quantity Must Contain Number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtElecQuantity.Focus();
                    return;
                }
                ord.Total = Convert.ToInt32(txtElecTotal.Text);
                ord.BARoomNo = txtElecBARoomNo.Text;
                ord.BACity = txtElecBACity.Text;
                ord.BAState = cmbElecBAState.SelectedItem.ToString();
                ord.BAPincode = txtElecBAPincode.Text;
                ord.SARoomNo = txtElecSARoomNo.Text;
                ord.SACity = txtElecSACity.Text;
                ord.SAState = cmbElecSAState.Text;
                ord.SAPincode = txtElecSAPincode.Text;
                try
                {
                    bool flag = cv.addOrder(ord);
                    bool flag1 = cv.updateProduct(Convert.ToInt32(txtElecQuantity.Text), cmbElecProduct.SelectedItem.ToString());
                    if (flag && flag1)
                    {
                        MessageBox.Show("Order Placed");
                        ClearAll();
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                catch (CustomerException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                catch (SystemException ex)
                {
                    MessageBox.Show(ex.Message);
                }        
        }

        private void cmbHAProduct_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable tb = new DataTable();
                tb = cv.getProductByName(cmbHAProduct.SelectedItem.ToString());
                DataSet ds = new DataSet();
                ds.Tables.Add(tb);
                txtHAPID.Text = ds.Tables[0].Rows[0][0].ToString();
                txtHAPrice.Text = ds.Tables[0].Rows[0][6].ToString();
                txtHADesc.Text = ds.Tables[0].Rows[0][10].ToString();
                Byte[] data = new Byte[0];
                data = (Byte[])(ds.Tables[0].Rows[0][8]);
                MemoryStream mem = new MemoryStream(data);
                picboxHA.Image = Image.FromStream(mem);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbMenProduct_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable tb = new DataTable();
                tb = cv.getProductByName(cmbMenProduct.SelectedItem.ToString());
                DataSet ds = new DataSet();
                ds.Tables.Add(tb);
                txtMenPID.Text = ds.Tables[0].Rows[0][0].ToString();
                txtMenPrice.Text = ds.Tables[0].Rows[0][6].ToString();                
                txtMenDesc.Text = ds.Tables[0].Rows[0][10].ToString();
                Byte[] data = new Byte[0];
                data = (Byte[])(ds.Tables[0].Rows[0][8]);
                MemoryStream mem = new MemoryStream(data);
                picboxMen.Image = Image.FromStream(mem);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void cmbWomenProduct_SelectedValueChanged(object sender, EventArgs e)
        {
            try
            {
                DataTable tb = new DataTable();
                tb = cv.getProductByName(cmbWomenProduct.SelectedItem.ToString());
                DataSet ds = new DataSet();
                ds.Tables.Add(tb);
                txtWomenPID.Text = ds.Tables[0].Rows[0][0].ToString();
                txtWomenPrice.Text = ds.Tables[0].Rows[0][6].ToString();
                txtWomenDesc.Text = ds.Tables[0].Rows[0][10].ToString();
                Byte[] data = new Byte[0];
                data = (Byte[])(ds.Tables[0].Rows[0][8]);
                MemoryStream mem = new MemoryStream(data);
                picboxWomen.Image = Image.FromStream(mem);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    

        private void txtElecBARoomNo_Leave(object sender, EventArgs e)
        {
            txtElecSARoomNo.Text = txtElecBARoomNo.Text;
        }

        private void txtElecBACity_Leave(object sender, EventArgs e)
        {
            txtElecSACity.Text = txtElecBACity.Text;
        }

        private void txtElecBAPincode_Leave(object sender, EventArgs e)
        {
            txtElecSAPincode.Text = txtElecBAPincode.Text;
        }

        private void cmbElecBAState_Leave(object sender, EventArgs e)
        {
            cmbElecSAState.SelectedIndex = cmbElecBAState.SelectedIndex;
        }

       
                   

        

        private void txtHABARoomNo_Leave(object sender, EventArgs e)
        {
            txtHASARoomNo.Text = txtHABARoomNo.Text;
        }
        private void txtHABACity_Leave(object sender, EventArgs e)
        {
            txtHASACity.Text = txtHABACity.Text;
        }

        private void cmbHABAState_Leave(object sender, EventArgs e)
        {
            cmbHASAState.SelectedIndex = cmbHABAState.SelectedIndex;
        }

        private void txtHABAPincode_Leave(object sender, EventArgs e)
        {
            txtHASAPincode.Text = txtHABAPincode.Text;
        }

        private void txtMenBARoomNo_Layout(object sender, LayoutEventArgs e)
        {
            txtMenSARoomNo.Text = txtMenBARoomNo.Text;
        }

        private void txtMenBACity_Leave(object sender, EventArgs e)
        {
            txtMenSACity.Text = txtMenBACity.Text;
        }

        private void cmbMenBAState_Leave(object sender, EventArgs e)
        {
            cmbMenSAState.Text = cmbMenBAState.Text;
        }

        private void txtMenBAPincode_Leave(object sender, EventArgs e)
        {
            txtMenSAPincode.Text = txtMenBAPincode.Text;
        }

        private void txtWomenBARoomNo_Leave(object sender, EventArgs e)
        {
            txtWomenSARoomNo.Text = txtWomenBARoomNo.Text;
        }

        private void txtWomenBACity_Leave(object sender, EventArgs e)
        {
            txtWomenSACity.Text = txtWomenBACity.Text;
        }

        private void cmbWomenBAState_Leave(object sender, EventArgs e)
        {
            cmbWomenSAState.Text = cmbWomenBAState.Text;
        }

        private void txtWomenBAPincode_Leave(object sender, EventArgs e)
        {
            txtWomenSAPincode.Text = txtWomenBAPincode.Text;
        }

        private void btnHABuy_Click(object sender, EventArgs e)
        {
            Order ord = new Order();
            ord.ODate = DateTime.Now;
            ord.CustomerID = Convert.ToInt32(lblUID.Text);
            ord.ProductID = Convert.ToInt32(txtHAPID.Text);
            ord.Price = Convert.ToInt32(txtHAPrice.Text);
            isNumber = int.TryParse(txtHAQuantity.Text, out result);
            if (isNumber)
                ord.Quantity = result;
            else
            {
                MessageBox.Show("Quantity Must Contain number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ord.Total = Convert.ToInt32(txtHATotal.Text);
            ord.BARoomNo = txtHABARoomNo.Text;
            ord.BACity = txtHABACity.Text;
            ord.BAState = cmbHABAState.SelectedItem.ToString();
            ord.BAPincode = txtHABAPincode.Text;
            ord.SARoomNo = txtHASARoomNo.Text;
            ord.SACity = txtHASACity.Text;
            ord.SAState = cmbHASAState.Text;
            ord.SAPincode = txtHASAPincode.Text;
            try
            {
                bool flag = cv.addOrder(ord);
                bool flag1 = cv.updateProduct(Convert.ToInt32(txtHAQuantity.Text), cmbHAProduct.SelectedItem.ToString());
                if (flag && flag1)
                {
                    MessageBox.Show("Order Placed");
                    ClearAll();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnMenBuy_Click(object sender, EventArgs e)
        {
            Order ord = new Order();
            ord.ODate = DateTime.Now;
            ord.CustomerID = Convert.ToInt32(lblUID.Text);
            ord.ProductID = Convert.ToInt32(txtMenPID.Text);
            ord.Price = Convert.ToInt32(txtMenPrice.Text);
            isNumber = int.TryParse(txtMenQuantity.Text, out result);
            if (isNumber)
                ord.Quantity = result;
            else
            {
                MessageBox.Show("Quantity Must Contain number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ord.Total = Convert.ToInt32(txtMenTotal.Text);
            ord.BARoomNo = txtMenBARoomNo.Text;
            ord.BACity = txtMenBACity.Text;
            ord.BAState = cmbMenBAState.SelectedItem.ToString();
            ord.BAPincode = txtMenBAPincode.Text;
            ord.SARoomNo = txtMenSARoomNo.Text;
            ord.SACity = txtMenSACity.Text;
            ord.SAState = cmbMenSAState.Text;
            ord.SAPincode = txtMenSAPincode.Text;
            try
            {
                bool flag = cv.addOrder(ord);
                bool flag1 = cv.updateProduct(Convert.ToInt32(txtMenQuantity.Text), cmbMenProduct.SelectedItem.ToString());
                if (flag && flag1)
                {
                    MessageBox.Show("Order Placed");
                    ClearAll();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnWomenBuy_Click(object sender, EventArgs e)
        {
            Order ord = new Order();
            ord.ODate = DateTime.Now;
            ord.CustomerID = Convert.ToInt32(lblUID.Text);
            ord.ProductID = Convert.ToInt32(txtWomenPID.Text);
            ord.Price = Convert.ToInt32(txtWomenPrice.Text);
            isNumber = int.TryParse(txtWomenQuantity.Text, out result);
            if (isNumber)
                ord.Quantity = result;
            else
            {
                MessageBox.Show("Quantity Must Contain number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            ord.Total = Convert.ToInt32(txtWomenTotal.Text);
            ord.BARoomNo = txtWomenBARoomNo.Text;
            ord.BACity = txtWomenBACity.Text;
            ord.BAState = cmbWomenBAState.SelectedItem.ToString();
            ord.BAPincode = txtWomenBAPincode.Text;
            ord.SARoomNo = txtWomenSARoomNo.Text;
            ord.SACity = txtWomenSACity.Text;
            ord.SAState = cmbWomenSAState.Text;
            ord.SAPincode = txtWomenSAPincode.Text;
            try
            {
                bool flag = cv.addOrder(ord);
                bool flag1 = cv.updateProduct(Convert.ToInt32(txtWomenQuantity.Text), cmbWomenProduct.SelectedItem.ToString());
                if (flag)
                {
                    MessageBox.Show("Order Placed");
                    ClearAll();
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        

        private void tpHomeAppliances_Click(object sender, EventArgs e)
        {
            ClearAll();
            panelElecCart.Visible = false;
        }

        private void tabCnt_Selected(object sender, TabControlEventArgs e)
        {
            
            if (e.TabPage == tpHome)
            {
                
                panelElecCart.Visible = false;
                panelHACart.Visible = false;
                panelMenCart.Visible = false;
                panelWomenCart.Visible = false;

                picboxElec.Visible = false;
                picboxHA.Visible = false;
                picboxMen.Visible = false;
                picboxWomen.Visible = false;

                txtElecDesc.Visible = false;
                txtHADesc.Visible = false;
                txtMenDesc.Visible = false;
                txtWomenDesc.Visible = false;


                //clear function

                txtHAQuantity.Clear();
                txtHATotal.Clear();
                txtHADesc.Clear();
                txtHABARoomNo.Clear();
                txtHABACity.Clear();
                txtHABAPincode.Clear();
                txtHASARoomNo.Clear();
                txtHASACity.Clear();
                txtHASAPincode.Clear();
                cmbElecBAState.SelectedIndex = -1;
                cmbHABAState.SelectedIndex = -1;
                cmbMenBAState.SelectedIndex = -1;
                cmbWomenBAState.SelectedIndex = -1;

                //cmbElecCategory.SelectedIndex = -1;
                //cmbElecProduct.SelectedIndex = -1;
                //cmbHACategory.SelectedIndex = -1;
                //cmbHAProduct.SelectedIndex = -1;
                //cmbMenCategory.SelectedIndex = -1;
                //cmbMenProduct.SelectedIndex = -1;
                //cmbWomenProduct.SelectedIndex = -1;
                //cmbWomenCategory.SelectedIndex = -1;

                cmbElecSAState.SelectedIndex = -1;
                cmbHASAState.SelectedIndex = -1;
                cmbMenSAState.SelectedIndex = -1;
                cmbWomenSAState.SelectedIndex = -1;


                txtElecQuantity.Clear();
                txtElecTotal.Clear();
                txtElecDesc.Clear();
                txtElecBARoomNo.Clear();
                txtElecBACity.Clear();
                txtElecBAPincode.Clear();
                txtElecSARoomNo.Clear();
                txtElecSACity.Clear();
                txtElecSAPincode.Clear();


                txtMenQuantity.Clear();
                txtMenTotal.Clear();
                txtMenDesc.Clear();
                txtMenBARoomNo.Clear();
                txtMenBACity.Clear();
                txtMenBAPincode.Clear();
                txtMenSARoomNo.Clear();
                txtMenSACity.Clear();
                txtMenSAPincode.Clear();


                txtWomenQuantity.Clear();
                txtWomenTotal.Clear();
                txtMenDesc.Clear();
                txtWomenBARoomNo.Clear();
                txtWomenBACity.Clear();
                txtWomenBAPincode.Clear();
                txtWomenSARoomNo.Clear();
                txtWomenSACity.Clear();
                txtWomenSAPincode.Clear();
                

            }

            //Electronic panel
            if (e.TabPage == tpElectronics)
            {
                
                panelHACart.Visible = false;
                panelMenCart.Visible = false;
                panelWomenCart.Visible = false;

                picboxElec.Visible =true;
                picboxHA.Visible = false;
                picboxMen.Visible = false;
                picboxWomen.Visible = false;

                txtElecDesc.Visible = true;
                txtHADesc.Visible = false;
                txtMenDesc.Visible = false;
                txtWomenDesc.Visible = false;

                //clear function

                txtHAQuantity.Clear();
                txtHATotal.Clear();
                txtHADesc.Clear();
                txtHABARoomNo.Clear();
                txtHABACity.Clear();
                txtHABAPincode.Clear();
                txtHASARoomNo.Clear();
                txtHASACity.Clear();
                txtHASAPincode.Clear();
                
                cmbHABAState.SelectedIndex = -1;
                cmbMenBAState.SelectedIndex = -1;
                cmbWomenBAState.SelectedIndex = -1;

                //cmbHACategory.SelectedIndex = -1;
                //cmbHAProduct.SelectedIndex = -1;
                //cmbMenCategory.SelectedIndex = -1;
                //cmbMenProduct.SelectedIndex = -1;
                //cmbWomenProduct.SelectedIndex = -1;
                //cmbWomenCategory.SelectedIndex = -1;

                cmbHASAState.SelectedIndex = -1;
                cmbMenSAState.SelectedIndex = -1;
                cmbWomenSAState.SelectedIndex = -1;


                txtMenQuantity.Clear();
                txtMenTotal.Clear();
                txtMenDesc.Clear();
                txtMenBARoomNo.Clear();
                txtMenBACity.Clear();
                txtMenBAPincode.Clear();
                txtMenSARoomNo.Clear();
                txtMenSACity.Clear();
                txtMenSAPincode.Clear();
                


                txtWomenQuantity.Clear();
                txtWomenTotal.Clear();
                txtMenDesc.Clear();
                txtWomenBARoomNo.Clear();
                txtWomenBACity.Clear();
                txtWomenBAPincode.Clear();
                txtWomenSARoomNo.Clear();
                txtWomenSACity.Clear();
                txtWomenSAPincode.Clear();
                
            }


            //Home Appliances panel
            if (e.TabPage == tpHomeAppliances)
            {

                panelElecCart.Visible = false;
                panelMenCart.Visible = false;
                panelWomenCart.Visible = false;

                picboxElec.Visible = false;
                picboxHA.Visible = true;
                picboxMen.Visible = false;
                picboxWomen.Visible = false;

                txtElecDesc.Visible = false;
                txtHADesc.Visible = true;
                txtMenDesc.Visible = false;
                txtWomenDesc.Visible = false;



                //clear function

                //cmbElecCategory.SelectedIndex = -1;
                //cmbElecProduct.SelectedIndex = -1;
                //cmbMenCategory.SelectedIndex = -1;
                //cmbMenProduct.SelectedIndex = -1;
                //cmbWomenProduct.SelectedIndex = -1;
                //cmbWomenCategory.SelectedIndex = -1;

                cmbElecSAState.SelectedIndex = -1;
                cmbMenSAState.SelectedIndex = -1;
                cmbWomenSAState.SelectedIndex = -1;


                txtElecQuantity.Clear();
                txtElecTotal.Clear();
                txtElecDesc.Clear();
                txtElecBARoomNo.Clear();
                txtElecBACity.Clear();
                txtElecBAPincode.Clear();
                txtElecSARoomNo.Clear();
                txtElecSACity.Clear();
                txtElecSAPincode.Clear();


                txtMenQuantity.Clear();
                txtMenTotal.Clear();
                txtMenDesc.Clear();
                txtMenBARoomNo.Clear();
                txtMenBACity.Clear();
                txtMenBAPincode.Clear();
                txtMenSARoomNo.Clear();
                txtMenSACity.Clear();
                txtMenSAPincode.Clear();
               
                txtWomenQuantity.Clear();
                txtWomenTotal.Clear();
                txtMenDesc.Clear();
                txtWomenBARoomNo.Clear();
                txtWomenBACity.Clear();
                txtWomenBAPincode.Clear();
                txtWomenSARoomNo.Clear();
                txtWomenSACity.Clear();
                txtWomenSAPincode.Clear();
            }


            //Men panel
            if (e.TabPage == tpMen)
            {
                
                panelElecCart.Visible = false;
                panelHACart.Visible = false;
                panelWomenCart.Visible = false;

                picboxElec.Visible = false;
                picboxHA.Visible = false;
                picboxMen.Visible = true;
                picboxWomen.Visible = false;

                txtElecDesc.Visible = false;
                txtHADesc.Visible = false;
                txtMenDesc.Visible = true;
                txtWomenDesc.Visible = false;

                //clear function

                txtHAQuantity.Clear();
                txtHATotal.Clear();
                txtHADesc.Clear();
                txtHABARoomNo.Clear();
                txtHABACity.Clear();
                txtHABAPincode.Clear();
                txtHASARoomNo.Clear();
                txtHASACity.Clear();
                txtHASAPincode.Clear();

                cmbElecBAState.SelectedIndex = -1;
                cmbHABAState.SelectedIndex = -1;
                cmbWomenBAState.SelectedIndex = -1;

                //cmbElecCategory.SelectedIndex = -1;
                //cmbElecProduct.SelectedIndex = -1;
                //cmbHACategory.SelectedIndex = -1;
                //cmbHAProduct.SelectedIndex = -1;
                //cmbWomenProduct.SelectedIndex = -1;
                //cmbWomenCategory.SelectedIndex = -1;

                cmbElecSAState.SelectedIndex = -1;
                cmbHASAState.SelectedIndex = -1;
                cmbWomenSAState.SelectedIndex = -1;


                txtElecQuantity.Clear();
                txtElecTotal.Clear();
                txtElecDesc.Clear();
                txtElecBARoomNo.Clear();
                txtElecBACity.Clear();
                txtElecBAPincode.Clear();
                txtElecSARoomNo.Clear();
                txtElecSACity.Clear();
                txtElecSAPincode.Clear();

                txtWomenQuantity.Clear();
                txtWomenTotal.Clear();
                txtWomenBARoomNo.Clear();
                txtWomenBACity.Clear();
                txtWomenBAPincode.Clear();
                txtWomenSARoomNo.Clear();
                txtWomenSACity.Clear();
                txtWomenSAPincode.Clear();
                 
            }

            //women panel
            if (e.TabPage == tpWomen)
            {
               
                panelElecCart.Visible = false;
                panelHACart.Visible = false;
                panelMenCart.Visible = false;

                picboxElec.Visible = false;
                picboxHA.Visible = false;
                picboxMen.Visible = false;
                picboxWomen.Visible = true;

                txtElecDesc.Visible = false;
                txtHADesc.Visible = false;
                txtMenDesc.Visible = false;
                txtWomenDesc.Visible = true;

                //clear function

                txtHAQuantity.Clear();
                txtHATotal.Clear();
                txtHADesc.Clear();
                txtHABARoomNo.Clear();
                txtHABACity.Clear();
                txtHABAPincode.Clear();
                txtHASARoomNo.Clear();
                txtHASACity.Clear();
                txtHASAPincode.Clear();

                cmbElecBAState.SelectedIndex = -1;
                cmbHABAState.SelectedIndex = -1;
                cmbMenBAState.SelectedIndex = -1;

                //cmbElecCategory.SelectedIndex = -1;
                //cmbElecProduct.SelectedIndex = -1;
                //cmbHACategory.SelectedIndex = -1;
                //cmbHAProduct.SelectedIndex = -1;
                //cmbMenCategory.SelectedIndex = -1;
                //cmbMenProduct.SelectedIndex = -1;
                
                cmbElecSAState.SelectedIndex = -1;
                cmbHASAState.SelectedIndex = -1;
                cmbMenSAState.SelectedIndex = -1;
                
                txtElecQuantity.Clear();
                txtElecTotal.Clear();
                txtElecDesc.Clear();
                txtElecBARoomNo.Clear();
                txtElecBACity.Clear();
                txtElecBAPincode.Clear();
                txtElecSARoomNo.Clear();
                txtElecSACity.Clear();
                txtElecSAPincode.Clear();


                txtMenQuantity.Clear();
                txtMenTotal.Clear();
                txtMenDesc.Clear();
                txtMenBARoomNo.Clear();
                txtMenBACity.Clear();
                txtMenBAPincode.Clear();
                txtMenSARoomNo.Clear();
                txtMenSACity.Clear();
                txtMenSAPincode.Clear();

                              
            }
        }

        private void txtElecQuantity_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                int quant = 0;
                isNumber = int.TryParse(txtElecQuantity.Text, out result);
                if (isNumber)
                    quant = result;
                try
                {
                    if (quantity < quant)
                    {
                        MessageBox.Show("Product Quantity Insufficient");
                    }
                    else
                    {
                        if (Convert.ToInt32(txtElecQuantity.Text) <= 0)
                        {
                            MessageBox.Show("Invalid Quantity");
                            txtElecQuantity.Clear();
                            txtElecQuantity.Focus();
                        }
                        else
                        {
                            txtElecTotal.Text = (Convert.ToInt32(txtElecPrice.Text) * Convert.ToInt32(txtElecQuantity.Text)).ToString();
                            txtElecBillDate.Text = DateTime.Now.ToShortDateString();
                        }
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                catch (CustomerException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                catch (SystemException ex)
                {
                    MessageBox.Show("Quantity Must Contain Number");
                    txtElecQuantity.Clear();

                }
            }

        }

        private void txtHAQuantity_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                int quant = 0;
            isNumber = int.TryParse(txtHAQuantity.Text, out result);
            if (isNumber)
                quant = result;
            try
            {
                if (quantity < quant)
                {
                    MessageBox.Show("Product Quantity Insufficient");
                }
                else
                {
                    if (Convert.ToInt32(txtHAQuantity.Text) <= 0)
                    {
                        MessageBox.Show("Invalid Quantity");
                        txtHAQuantity.Clear();
                        txtHAQuantity.Focus();
                    }
                    else
                    {
                        txtHATotal.Text = (Convert.ToInt32(txtHAPrice.Text) * Convert.ToInt32(txtHAQuantity.Text)).ToString();
                        txtHABillDate.Text = DateTime.Now.ToShortDateString();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show("Quantity Must Contain Number");
                txtHAQuantity.Clear();
                txtHAQuantity.Focus();
            }
        }

        }

        private void txtMenQuantity_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {

                int quant = 0;
                isNumber = int.TryParse(txtMenQuantity.Text, out result);
                if (isNumber)
                    quant = result;

                try
                {

                    if (quantity < quant)
                    {
                        MessageBox.Show("Product Quantity Insufficient");
                    }
                    else
                    {
                        if (Convert.ToInt32(txtMenQuantity.Text) <= 0)
                        {
                            MessageBox.Show("Invalid Quantity");
                            txtMenQuantity.Clear();
                            txtMenQuantity.Focus();
                        }
                        else
                        {
                            txtMenTotal.Text = (Convert.ToInt32(txtMenPrice.Text) * Convert.ToInt32(txtMenQuantity.Text)).ToString();
                            txtMenBilDate.Text = DateTime.Now.ToShortDateString();
                        }
                    }
                }
                catch (SqlException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                catch (CustomerException ex)
                {
                    MessageBox.Show(ex.Message);
                }
                catch (SystemException ex)
                {
                    MessageBox.Show("Quantity Must Contain Number");
                    txtMenQuantity.Clear();
                    txtMenQuantity.Focus();
                }
            }
        }

        private void txtWomenQuantity_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                int quant = 0;
            isNumber = int.TryParse(txtWomenQuantity.Text, out result);
            if (isNumber)
                quant = result;
            try
            {
                isNumber = int.TryParse(txtWomenQuantity.Text, out result);
                if (isNumber)
                    quant = result;
                else
                {
                    MessageBox.Show("Quantity Must Contain number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtWomenQuantity.Clear();
                    txtWomenQuantity.Focus();
                }
                if (quantity < quant)
                {
                    MessageBox.Show("Product Quantity Insufficient");
                }
                else
                {
                    if (Convert.ToInt32(txtWomenQuantity.Text) <= 0)
                    {
                        MessageBox.Show("Invalid Quantity");
                        txtWomenQuantity.Clear();
                        txtWomenQuantity.Focus();
                    }
                    else
                    {
                        txtWomenTotal.Text = (Convert.ToInt32(txtWomenPrice.Text) * Convert.ToInt32(txtWomenQuantity.Text)).ToString();
                        txtWomenBillDate.Text = DateTime.Now.ToShortDateString();
                    }
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show("Quantity Must Contain Number");
                txtWomenQuantity.Clear();
                txtWomenQuantity.Focus();
            }
        }

        }

               

    }
}