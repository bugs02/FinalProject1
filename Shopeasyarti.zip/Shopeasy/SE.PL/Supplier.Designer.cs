﻿namespace SE.PL
{
    partial class Supplier
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tbAddProd = new System.Windows.Forms.TabPage();
            this.btnSaveSupplier = new System.Windows.Forms.Button();
            this.txtSID = new System.Windows.Forms.TextBox();
            this.txtDesc = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.btnUpload = new System.Windows.Forms.Button();
            this.picBox = new System.Windows.Forms.PictureBox();
            this.txtUnitPrice = new System.Windows.Forms.TextBox();
            this.cmbCID = new System.Windows.Forms.ComboBox();
            this.txtRanking = new System.Windows.Forms.TextBox();
            this.txtDiscount = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtMRP = new System.Windows.Forms.TextBox();
            this.txtUnits = new System.Windows.Forms.TextBox();
            this.txtPName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tbUpdateProd = new System.Windows.Forms.TabPage();
            this.tbDeleteProd = new System.Windows.Forms.TabPage();
            this.lblLogo = new System.Windows.Forms.Label();
            this.linklblLogOut = new System.Windows.Forms.LinkLabel();
            this.lblSID = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tabControl1.SuspendLayout();
            this.tbAddProd.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tbAddProd);
            this.tabControl1.Controls.Add(this.tbUpdateProd);
            this.tabControl1.Controls.Add(this.tbDeleteProd);
            this.tabControl1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(197, 50);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(957, 628);
            this.tabControl1.TabIndex = 0;
            // 
            // tbAddProd
            // 
            this.tbAddProd.Controls.Add(this.btnSaveSupplier);
            this.tbAddProd.Controls.Add(this.txtSID);
            this.tbAddProd.Controls.Add(this.txtDesc);
            this.tbAddProd.Controls.Add(this.label10);
            this.tbAddProd.Controls.Add(this.btnUpload);
            this.tbAddProd.Controls.Add(this.picBox);
            this.tbAddProd.Controls.Add(this.txtUnitPrice);
            this.tbAddProd.Controls.Add(this.cmbCID);
            this.tbAddProd.Controls.Add(this.txtRanking);
            this.tbAddProd.Controls.Add(this.txtDiscount);
            this.tbAddProd.Controls.Add(this.label9);
            this.tbAddProd.Controls.Add(this.label8);
            this.tbAddProd.Controls.Add(this.txtMRP);
            this.tbAddProd.Controls.Add(this.txtUnits);
            this.tbAddProd.Controls.Add(this.txtPName);
            this.tbAddProd.Controls.Add(this.label7);
            this.tbAddProd.Controls.Add(this.label6);
            this.tbAddProd.Controls.Add(this.label5);
            this.tbAddProd.Controls.Add(this.label4);
            this.tbAddProd.Controls.Add(this.label3);
            this.tbAddProd.Controls.Add(this.label2);
            this.tbAddProd.Location = new System.Drawing.Point(4, 30);
            this.tbAddProd.Name = "tbAddProd";
            this.tbAddProd.Padding = new System.Windows.Forms.Padding(3);
            this.tbAddProd.Size = new System.Drawing.Size(949, 594);
            this.tbAddProd.TabIndex = 0;
            this.tbAddProd.Text = "Add Product";
            this.tbAddProd.UseVisualStyleBackColor = true;
            // 
            // btnSaveSupplier
            // 
            this.btnSaveSupplier.AllowDrop = true;
            this.btnSaveSupplier.Location = new System.Drawing.Point(353, 528);
            this.btnSaveSupplier.Name = "btnSaveSupplier";
            this.btnSaveSupplier.Size = new System.Drawing.Size(225, 29);
            this.btnSaveSupplier.TabIndex = 43;
            this.btnSaveSupplier.Text = "Save ";
            this.btnSaveSupplier.UseVisualStyleBackColor = true;
            this.btnSaveSupplier.Click += new System.EventHandler(this.btnSaveSupplier_Click);
            // 
            // txtSID
            // 
            this.txtSID.Enabled = false;
            this.txtSID.Location = new System.Drawing.Point(202, 92);
            this.txtSID.Name = "txtSID";
            this.txtSID.Size = new System.Drawing.Size(223, 29);
            this.txtSID.TabIndex = 42;
            // 
            // txtDesc
            // 
            this.txtDesc.Location = new System.Drawing.Point(702, 32);
            this.txtDesc.Multiline = true;
            this.txtDesc.Name = "txtDesc";
            this.txtDesc.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.txtDesc.Size = new System.Drawing.Size(223, 160);
            this.txtDesc.TabIndex = 41;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(487, 40);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(161, 21);
            this.label10.TabIndex = 40;
            this.label10.Text = "Product Description";
            // 
            // btnUpload
            // 
            this.btnUpload.Location = new System.Drawing.Point(491, 409);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(144, 31);
            this.btnUpload.TabIndex = 39;
            this.btnUpload.Text = "Upload Image";
            this.btnUpload.UseVisualStyleBackColor = true;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // picBox
            // 
            this.picBox.Location = new System.Drawing.Point(491, 229);
            this.picBox.Name = "picBox";
            this.picBox.Size = new System.Drawing.Size(372, 162);
            this.picBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picBox.TabIndex = 38;
            this.picBox.TabStop = false;
            // 
            // txtUnitPrice
            // 
            this.txtUnitPrice.Location = new System.Drawing.Point(202, 263);
            this.txtUnitPrice.Name = "txtUnitPrice";
            this.txtUnitPrice.Size = new System.Drawing.Size(223, 29);
            this.txtUnitPrice.TabIndex = 36;
            // 
            // cmbCID
            // 
            this.cmbCID.FormattingEnabled = true;
            this.cmbCID.Location = new System.Drawing.Point(202, 151);
            this.cmbCID.Name = "cmbCID";
            this.cmbCID.Size = new System.Drawing.Size(223, 29);
            this.cmbCID.TabIndex = 35;
            // 
            // txtRanking
            // 
            this.txtRanking.Location = new System.Drawing.Point(202, 453);
            this.txtRanking.Name = "txtRanking";
            this.txtRanking.Size = new System.Drawing.Size(223, 29);
            this.txtRanking.TabIndex = 33;
            // 
            // txtDiscount
            // 
            this.txtDiscount.Location = new System.Drawing.Point(202, 393);
            this.txtDiscount.Name = "txtDiscount";
            this.txtDiscount.Size = new System.Drawing.Size(223, 29);
            this.txtDiscount.TabIndex = 32;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(24, 461);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 21);
            this.label9.TabIndex = 30;
            this.label9.Text = "Ranking";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(24, 401);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(77, 21);
            this.label8.TabIndex = 29;
            this.label8.Text = "Discount";
            // 
            // txtMRP
            // 
            this.txtMRP.Location = new System.Drawing.Point(202, 328);
            this.txtMRP.Name = "txtMRP";
            this.txtMRP.Size = new System.Drawing.Size(223, 29);
            this.txtMRP.TabIndex = 28;
            // 
            // txtUnits
            // 
            this.txtUnits.Location = new System.Drawing.Point(202, 213);
            this.txtUnits.Name = "txtUnits";
            this.txtUnits.Size = new System.Drawing.Size(223, 29);
            this.txtUnits.TabIndex = 26;
            // 
            // txtPName
            // 
            this.txtPName.Location = new System.Drawing.Point(202, 40);
            this.txtPName.Name = "txtPName";
            this.txtPName.Size = new System.Drawing.Size(223, 29);
            this.txtPName.TabIndex = 23;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(24, 336);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 21);
            this.label7.TabIndex = 21;
            this.label7.Text = "MRP";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(24, 271);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 21);
            this.label6.TabIndex = 20;
            this.label6.Text = "Unit Price";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 221);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 21);
            this.label5.TabIndex = 19;
            this.label5.Text = "Units";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 159);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(78, 21);
            this.label4.TabIndex = 18;
            this.label4.Text = "Category";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(24, 100);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 21);
            this.label3.TabIndex = 17;
            this.label3.Text = "Supplier ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 21);
            this.label2.TabIndex = 16;
            this.label2.Text = "Product Name";
            // 
            // tbUpdateProd
            // 
            this.tbUpdateProd.Location = new System.Drawing.Point(4, 30);
            this.tbUpdateProd.Name = "tbUpdateProd";
            this.tbUpdateProd.Padding = new System.Windows.Forms.Padding(3);
            this.tbUpdateProd.Size = new System.Drawing.Size(949, 594);
            this.tbUpdateProd.TabIndex = 1;
            this.tbUpdateProd.Text = "Update Product";
            this.tbUpdateProd.UseVisualStyleBackColor = true;
            // 
            // tbDeleteProd
            // 
            this.tbDeleteProd.Location = new System.Drawing.Point(4, 30);
            this.tbDeleteProd.Name = "tbDeleteProd";
            this.tbDeleteProd.Size = new System.Drawing.Size(949, 594);
            this.tbDeleteProd.TabIndex = 2;
            this.tbDeleteProd.Text = "Delete Product";
            this.tbDeleteProd.UseVisualStyleBackColor = true;
            // 
            // lblLogo
            // 
            this.lblLogo.AutoSize = true;
            this.lblLogo.BackColor = System.Drawing.Color.Transparent;
            this.lblLogo.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogo.Location = new System.Drawing.Point(54, 50);
            this.lblLogo.Name = "lblLogo";
            this.lblLogo.Size = new System.Drawing.Size(120, 29);
            this.lblLogo.TabIndex = 3;
            this.lblLogo.Text = "Shopeasy";
            // 
            // linklblLogOut
            // 
            this.linklblLogOut.AutoSize = true;
            this.linklblLogOut.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklblLogOut.Location = new System.Drawing.Point(1082, 26);
            this.linklblLogOut.Name = "linklblLogOut";
            this.linklblLogOut.Size = new System.Drawing.Size(68, 21);
            this.linklblLogOut.TabIndex = 6;
            this.linklblLogOut.TabStop = true;
            this.linklblLogOut.Text = "LogOut";
            this.linklblLogOut.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linklblLogOut_LinkClicked);
            // 
            // lblSID
            // 
            this.lblSID.AutoSize = true;
            this.lblSID.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSID.Location = new System.Drawing.Point(997, 26);
            this.lblSID.Name = "lblSID";
            this.lblSID.Size = new System.Drawing.Size(0, 20);
            this.lblSID.TabIndex = 7;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Supplier
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 741);
            this.Controls.Add(this.lblSID);
            this.Controls.Add(this.linklblLogOut);
            this.Controls.Add(this.lblLogo);
            this.Controls.Add(this.tabControl1);
            this.Name = "Supplier";
            this.Text = "Supplier";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Activated += new System.EventHandler(this.Supplier_Activated);
            this.Load += new System.EventHandler(this.Supplier_Load);
            this.tabControl1.ResumeLayout(false);
            this.tbAddProd.ResumeLayout(false);
            this.tbAddProd.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tbAddProd;
        private System.Windows.Forms.TabPage tbUpdateProd;
        private System.Windows.Forms.Label lblLogo;
        private System.Windows.Forms.TabPage tbDeleteProd;
        private System.Windows.Forms.TextBox txtMRP;
        private System.Windows.Forms.TextBox txtUnits;
        private System.Windows.Forms.TextBox txtPName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.PictureBox picBox;
        private System.Windows.Forms.TextBox txtUnitPrice;
        private System.Windows.Forms.ComboBox cmbCID;
        private System.Windows.Forms.TextBox txtRanking;
        private System.Windows.Forms.TextBox txtDiscount;
        private System.Windows.Forms.TextBox txtDesc;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button btnSaveSupplier;
        private System.Windows.Forms.TextBox txtSID;
        private System.Windows.Forms.LinkLabel linklblLogOut;
        private System.Windows.Forms.Label lblSID;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}